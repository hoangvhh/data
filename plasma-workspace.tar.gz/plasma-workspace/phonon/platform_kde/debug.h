#ifndef DEBUG_H
#define DEBUG_H

#include <QLoggingCategory>

Q_DECLARE_LOGGING_CATEGORY(PLATFORM)

#endif // DEBUG_H
