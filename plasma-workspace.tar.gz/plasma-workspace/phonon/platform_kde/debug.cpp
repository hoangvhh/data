#include "debug.h"

Q_LOGGING_CATEGORY(PLATFORM, "phonon.kde.platformplugin")
