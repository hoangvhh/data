#! /bin/sh
#This file outputs in a separate line each file with a .desktop syntax
#that needs to be translated but has a non .desktop extension
find -name \*.kdevtemplate -print
