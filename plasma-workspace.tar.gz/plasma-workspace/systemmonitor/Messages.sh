#! /bin/sh
$XGETTEXT *.cpp -o $podir/systemmonitor.pot
