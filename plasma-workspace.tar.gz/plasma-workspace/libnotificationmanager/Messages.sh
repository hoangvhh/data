#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/libnotificationmanager.pot
