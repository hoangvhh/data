/*
 *  SPDX-FileCopyrightText: 2020 David Edmundson<ahiemstra@heimr.nl>
 *
 *  SPDX-License-Identifier: LGPL-2.0-or-later
 */

#include <QtQuickTest>
QUICK_TEST_MAIN(Kicker)
