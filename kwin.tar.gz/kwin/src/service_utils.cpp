/*
    KWin - the KDE window manager
    This file is part of the KDE project.

    SPDX-FileCopyrightText: 2020 Méven Car <meven.car@enioka.com>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

/*

 This file is for (very) small utility relating to services/process.

*/
#include "service_utils.h"

namespace KWin
{

}// namespace

