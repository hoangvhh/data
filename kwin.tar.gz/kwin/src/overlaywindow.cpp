/*
    KWin - the KDE window manager
    This file is part of the KDE project.

    SPDX-FileCopyrightText: 2011 Arthur Arlt <a.arlt@stud.uni-heidelberg.de>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

#include "overlaywindow.h"

namespace KWin {
OverlayWindow::OverlayWindow()
{
}

OverlayWindow::~OverlayWindow()
{
}

} // namespace KWin
